-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Aluno (
matricula_aluno int() not null, auto_increment PRIMARY KEY,
nome_pai varchar(20),
nome_mae varchar(20),
tel_contato int(),
cod_usuario int() not null
);

CREATE TABLE Professor (
titulacao varchar(20),
formacao varchar(20),
matricula_professor int() not null, auto_increment PRIMARY KEY,
cod_usuario int() not null
);

CREATE TABLE Disciplina (
ementa_disciplina varchar(20),
cod_disciplina int() not null, auto_increment PRIMARY KEY,
desc_disciplina varchar(1000),
nome_disciplina varchar(20),
matricula_professor int() not null,
FOREIGN KEY(matricula_professor) REFERENCES Professor (matricula_professor)
);

CREATE TABLE Usuario (
cpf int(),
rg int(),
cod_usuario int() not null, auto_increment PRIMARY KEY,
senha varchar(20),
nome_usuario varchar(20),
email varchar(20)
);

CREATE TABLE Curso (
desc_curso varchar(1000),
cod_curso int() not null, auto_increment PRIMARY KEY,
nome_curso varchar(60),
ppc_curso varchar(500)
);

CREATE TABLE Turmas (
qtd_aluno int(10),
cod_turma int() not null, auto_increment PRIMARY KEY,
desc_turma varchar(1000),
nome_turma varchar(60),
cod_curso int() not null,
FOREIGN KEY(cod_curso) REFERENCES Curso (cod_curso)
);

CREATE TABLE periodo+  (
matricula_aluno int() not null,
cod_turma int() not null,
dt_inicio date,
dt_termino date,
FOREIGN KEY(matricula_aluno) REFERENCES Aluno (matricula_aluno),
FOREIGN KEY(cod_turma) REFERENCES Turmas (cod_turma)
);

CREATE TABLE Aula (
cod_disciplina int() not null,
cod_turma int() not null,
desc_aula varchar(1000),
local_aula varchar(20),
dia_semana date,
hora_fim date,
hora_inicio date,
FOREIGN KEY(cod_disciplina) REFERENCES Disciplina (cod_disciplina),
FOREIGN KEY(cod_turma) REFERENCES Turmas (cod_turma)
);

ALTER TABLE Aluno ADD FOREIGN KEY(cod_usuario) REFERENCES Usuario (cod_usuario);
ALTER TABLE Professor ADD FOREIGN KEY(cod_usuario) REFERENCES Usuario (cod_usuario);
