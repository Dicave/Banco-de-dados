-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE aluno (
cod_aluno int PRIMARY KEY,
aluno_cod_turma int not null,
aluno_cod_curso int not null,
aluno_fone int,
aluno_endereco varchar(1000),
aluno_cpf int,
aluno_dataNascimento date,
aluno_rg int,
aluno_nome varchar(1000),
aluno_email varchar(100)
);

CREATE TABLE curso (
cod_curso int PRIMARY KEY,
curso_cod_professor int not null,
curso_cod_aluno int not null,
curso_qtd_alunos int,
curso_qtd_professores int,
curso_nome varchar(300),
curso_desc varchar(1000),
FOREIGN KEY(curso_cod_aluno) REFERENCES aluno (cod_aluno)
);

CREATE TABLE turma (
cod_turma int PRIMARY KEY,
turma_cod_professor int not null,
turma_cod_aluno int not null,
turma_desc varchar(1000),
turma_nome varchar(300),
FOREIGN KEY(turma_cod_aluno) REFERENCES aluno (cod_aluno)
);

CREATE TABLE aula (
aula_cod_disci int not null,
aula_cod_professor int not null,
aula_relatorio varchar(4000),
aula_qtd_alunos int
);

CREATE TABLE professor (
cod_professor int PRIMARY KEY,
prof_rg int,
prof_cpf int,
prof_dataNascimento date,
prof_nome varchar(300),
prof_email varchar(300),
prof_fone int
);

CREATE TABLE disciplina (
cod_disciplina int PRIMARY KEY,
disci_cod_professor int not null,
disci_desc varchar(3000),
disci_nome varchar(1000),
FOREIGN KEY(disci_cod_professor) REFERENCES professor (cod_professor)
);

ALTER TABLE aluno ADD FOREIGN KEY(aluno_cod_turma) REFERENCES turma (cod_turma);
ALTER TABLE aluno ADD FOREIGN KEY(aluno_cod_curso) REFERENCES curso (cod_curso);
ALTER TABLE curso ADD FOREIGN KEY(curso_cod_professor) REFERENCES professor (cod_professor);
ALTER TABLE turma ADD FOREIGN KEY(turma_cod_professor) REFERENCES professor (cod_professor);
ALTER TABLE aula ADD FOREIGN KEY(aula_cod_disci) REFERENCES disciplina (cod_disciplina);
ALTER TABLE aula ADD FOREIGN KEY(aula_cod_professor) REFERENCES professor (cod_professor);
