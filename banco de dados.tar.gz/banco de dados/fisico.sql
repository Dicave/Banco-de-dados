-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Turma (
cod_turma string() PRIMARY KEY,
nome_turma string(),
qtd_alunos int(4),
desc_turma varchar(250),
cod_disciplina string()
);

CREATE TABLE curso (
cod_curso string() PRIMARY KEY,
nome_curso string(),
ppc_curso string(),
desc_curso varchar(250),
cod_prof string()/*falha: chave estrangeira*/
);

CREATE TABLE professor (
cod_prof string() PRIMARY KEY,
nome_prof string(),
cod_turma string()/*falha: chave estrangeira*/
);

CREATE TABLE disciplina (
cod_disciplina string() PRIMARY KEY,
qtd_disciplina int(4),
nome_prof string()/*falha: chave estrangeira*/
);

ALTER TABLE Turma ADD FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina);
