CREATE TABLE pedido (
ped_cod int PRIMARY KEY,
ped_cli_cod int,
ped_prod_cod int,
ped_faturado varchar(400),
ped_data_ent date
);

CREATE TABLE produto (
prod_cod int PRIMARY KEY,
prod_preco float(20),
prod_quant_embCaixa bigint(1000),
prod_desc varchar(1000),
prod_quant_estoque bigint(1000)
);

CREATE TABLE pessoa_juridica (
cli_CNPJ int PRIMARY KEY,
cli_razao_social varchar(200)
);

CREATE TABLE cliente (
cli_cod int PRIMARY KEY,
cli_endereco_ent varchar(500),
cli_fone int,
cli_cel int,
cli_nome varchar(400),
cli_email varchar(400)
);

CREATE TABLE pessoa_fisica (
cli_CPF int PRIMARY KEY,
cli_RG int
);

CREATE TABLE comentario (
coment_cli_cod int,
coment_prod_cod int,
coment_data date,
coment_text varchar(3000),
coment_title varchar(500),
FOREIGN KEY(coment_cli_cod) REFERENCES cliente (cli_cod),
FOREIGN KEY(coment_prod_cod) REFERENCES produto (prod_cod)
);

ALTER TABLE pedido ADD FOREIGN KEY(ped_cli_cod) REFERENCES cliente (cli_cod);
ALTER TABLE pedido ADD FOREIGN KEY(ped_prod_cod) REFERENCES produto (prod_cod);
