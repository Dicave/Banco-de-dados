-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE curso (
cod_curso int(10) not null auto_increment PRIMARY KEY,
curso_cod_professor int(10) not null,
curso_cod_aluno int(10) not null,
curso_qtd_alunos int(10),
curso_qtd_professores int(10),
curso_nome varchar(300),
curso_desc varchar(1000)
);

CREATE TABLE turma (
cod_turma int(10) not null auto_increment PRIMARY KEY,
turma_cod_professor int(10) not null,
turma_cod_aluno int(10) not null,
turma_desc varchar(1000)
);

CREATE TABLE aula (
aula_cod_disci int(10) not null,
aula_cod_professor int(10) not null,
aula_relatorio varchar(4000),
aula_qtd_alunos int
);

CREATE TABLE professor (
cod_professor int(10) not null auto_increment PRIMARY KEY,
prof_rg int(10),
prof_cpf int(10),
prof_dataNascimento date,
prof_nome varchar(300),
prof_email varchar(300),
prof_fone int(10)
);

CREATE TABLE disciplina (
cod_disciplina int(10) not null auto_increment PRIMARY KEY,
disci_cod_professor int(10) not null,
disci_desc varchar(3000),
disci_nome varchar(1000),
FOREIGN KEY(disci_cod_professor) REFERENCES professor (cod_professor)
);

CREATE TABLE aluno (
cod_aluno int(10) not null auto_increment PRIMARY KEY,
aluno_cod_turma int(10) not null,
aluno_cod_curso int(10) not null,
aluno_fone int(10),
aluno_endereco varchar(1000),
aluno_cpf int(10),
aluno_dataNascimento date,
aluno_rg int(10),
aluno_nome varchar(1000),
aluno_email varchar(100),
FOREIGN KEY(aluno_cod_turma) REFERENCES turma (cod_turma),
FOREIGN KEY(aluno_cod_curso) REFERENCES curso (cod_curso)
);

ALTER TABLE curso ADD FOREIGN KEY(curso_cod_professor) REFERENCES professor (cod_professor);
ALTER TABLE curso ADD FOREIGN KEY(curso_cod_aluno) REFERENCES aluno (cod_aluno);
ALTER TABLE turma ADD FOREIGN KEY(turma_cod_professor) REFERENCES professor (cod_professor);
ALTER TABLE turma ADD FOREIGN KEY(turma_cod_aluno) REFERENCES aluno (cod_aluno);
ALTER TABLE aula ADD FOREIGN KEY(aula_cod_disci) REFERENCES disciplina (cod_disciplina);
ALTER TABLE aula ADD FOREIGN KEY(aula_cod_professor) REFERENCES professor (cod_professor);
